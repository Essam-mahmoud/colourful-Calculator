//
//  RadioClass.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 9/12/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import Foundation


class RadioClass {
    
   static var IsMenu : Bool = false
    
   static func ToggleMenu() {
        if IsMenu {
            NotificationCenter.default.post(name: Notification.Name(rawValue: "HideMenu"), object: nil)
            IsMenu = false
        
        } else {
            NotificationCenter.default.post(name: Notification.Name(rawValue: "ShowMenu"), object: nil)
            IsMenu = true
        }
    }
    
    
    
    
}
