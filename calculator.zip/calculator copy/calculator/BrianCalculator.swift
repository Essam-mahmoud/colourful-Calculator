//
//  BrianCalculator.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 8/30/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import Foundation

class BrainCalculator {
    // we first create new type contain number and operation
    // then put all values in an array to treate with all values and operation
    // operate with element as num & op if we have 10+10*10-10 treat with it as (10+)(10*)(10-)(10=)
    
    // create new type to able to save the number and operation
    typealias CalcElement = (Num : Double , Op : Character)
    
    // intialize array to collect all data in this array
    private var NumWithOpArray : [CalcElement] = []
    
    // function to add to the array
    func Add(Number : Double , with Operation : Character) {
        
        NumWithOpArray.append(CalcElement(Num : Number, Op : Operation))
        
    }
    func Restart () {
        NumWithOpArray = []
    }
    func Result () -> String {
        CalculateMulAndDivided()
        CalculateAllMinus()
        // calculate the rest(all operation be + only ) of number after the * & / & - operations
        return String(NumWithOpArray.reduce(0, {$0 + $1.Num}))
    }
    // function to check and operate with multiplication and division first
    func CalculateMulAndDivided () {
        
        for (index , current) in NumWithOpArray.enumerated() {
            if current.Op == "X" || current.Op == "/" {
                // to get second element in the array after found a multiply sign
                let afterCurrent = NumWithOpArray[index + 1]
                // create new element to put in it the result of operation if we found * or /
                var NewCalc : CalcElement!
                if current.Op == "X" {
                    NewCalc = CalcElement(Num : current.Num * afterCurrent.Num , Op : afterCurrent.Op)
                    
                } else if current.Op == "/" {
                    NewCalc = CalcElement(Num : current.Num / afterCurrent.Num , Op : afterCurrent.Op)
                }
                // remove the numbers that we * and / if we found
                NumWithOpArray.remove(at: index)
                NumWithOpArray.remove(at: index)
                // add the new number after operation
                NumWithOpArray.insert(NewCalc, at: index)
                CalculateMulAndDivided()
                break
            }
        }
    }
    
    // function to treate with( - )operation
    func CalculateAllMinus() {
        for (index , current) in NumWithOpArray.enumerated() {
            if current.Op == "-" {
                // to get second element in the array after found a multiply sign
                let afterCurrent = NumWithOpArray[index + 1]
                // create new element to put in it the result of operation if we found * or /
                var NewCalc : CalcElement!
                NewCalc = CalcElement(Num : current.Num - afterCurrent.Num , Op : "+")
                NumWithOpArray.remove(at: index) // remove the numbers that we * and / if we found
                NumWithOpArray.remove(at: index)
                NumWithOpArray.insert(NewCalc, at: index)  // add the new number after operation
                CalculateMulAndDivided()
                break
            }
        }
        
    }
    
    
    
    
    
    
    
    
    
}
