//
//  ViewController.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 8/29/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //to change the battery and culler color
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
   // function to hide and show side menu
    @IBAction func SideMenuAction(_ sender: UIButton) {
       RadioClass.ToggleMenu() 
    }
    
    
    // screen is the lable that show the result
    @IBOutlet weak var screen: UILabel!
    // create object from brain calculator class
    var Brain : BrainCalculator = BrainCalculator()
    // function to show number in screen
    @IBAction func NumberssAction(_ sender: UIButton) {
        
        // to delete zero in the begining of app
        if screen.text == "0" {
            screen.text = ""
        }
        if sender.tag == -1 {
            if !screen.text!.contains("."){
                screen.text = screen.text! + "."
            }
        } else {
            screen.text = screen.text! + String(sender.tag)
        }
        
    }
    // function to + - / * operations
    @IBAction func OperationsAction(_ sender: UIButton) {
        Brain.Add(Number: Double(screen.text!)! , with: Character(sender.titleLabel!.text!))
        if sender.titleLabel!.text! == "=" {
          screen.text = Brain.Result()
            Brain.Restart()
        } else {
            screen.text = "0"
        }
        
    }
    
    // function of the AC button
    @IBAction func AcButton(_ sender: UIButton) {
        screen.text = "0"
        Brain.Restart()
    }
    
    // function to change sign button
    @IBAction func ChangeSign(_ sender: UIButton) {
        screen.text = String(Double(screen.text!)! * -1)
    }
    // function to change % button
    @IBAction func Percentage(_ sender: UIButton) {
        screen.text = String(Double(screen.text!)! / 100)
    }
    
    
    
    
}




