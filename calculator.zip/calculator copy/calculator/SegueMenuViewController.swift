//
//  SegueMenuViewController.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 9/8/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit


class SegueMenuViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector:#selector(SegueMenuViewController.changeVc(notification:)), name: NSNotification.Name(rawValue: "changPage"), object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        performSegue(withIdentifier: "Calculator", sender: nil)
        
    }
    @objc func changeVc(notification : NSNotification){
        if let Dic = notification.userInfo as? [String : AnyObject] {
            if let name = Dic["ToVC"] as? String {
                performSegue(withIdentifier: name, sender: nil)
            }
        }
    }
}
