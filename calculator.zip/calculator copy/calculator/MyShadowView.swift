//
//  MyShadowView.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 8/30/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class MyShadowView: UIView {

    
    let Mylayer : CAGradientLayer = CAGradientLayer()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.shadowColor = UIColor.black.withAlphaComponent(0.4).cgColor
        self.layer.shadowRadius = 3
        self.layer.shadowOffset = CGSize(width: -3, height: -3)
        self.layer.shadowOpacity = 0.35
        
        // create gradient to colored the app and setup it
        
        
        let firstcolor = UIColor.init(red: 152/255, green: 53/255, blue: 160/255, alpha: 1).cgColor
        let secondcolor = UIColor.init(red: 85/255, green: 116/255 , blue: 200/255, alpha: 1).cgColor
        Mylayer.startPoint = CGPoint(x: 0, y: 0.3)
        Mylayer.endPoint = CGPoint(x: 0, y: 0.8)
        Mylayer.colors = [firstcolor , secondcolor]
        Mylayer.zPosition = -1
        self.layer.addSublayer(Mylayer)
    }
    // make this function to make changes in the view if the device is changed 
    override func layoutSubviews() {
        super.layoutSubviews()
        
        Mylayer.frame = CGRect(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height)
    }

}
