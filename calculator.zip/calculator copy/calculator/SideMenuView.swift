//
//  SideMenuView.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 9/8/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit


class SideMenuView: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func MenuAction(_ sender: UIButton) {
        var ToVc : String = ""
        if sender.tag == 0 {
            //Main
            ToVc = "Calculator"
            
        } else if sender.tag == 1 {
            //Setting
            ToVc = "Setting"
            
        } else if sender.tag == 2 {
            //contact us
            ToVc = "Contact Us"
            
        }
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "changPage"), object: nil, userInfo: ["ToVC" : ToVc])
    }
    
    
}
