//
//  BigViewController.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 9/12/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit


class BigViewController: UIViewController{
    
    @IBOutlet weak var SideMenuLayout: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(BigViewController.HideMenu), name: NSNotification.Name(rawValue: "HideMenu"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(BigViewController.ShowMenu), name: NSNotification.Name(rawValue: "ShowMenu"), object: nil)
    }
    @objc func HideMenu() {
        SideMenuLayout.constant = 0
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
        }
    }
    @objc func ShowMenu() {
        SideMenuLayout.constant = self.view.frame.size.width * 0.7
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
        }
    }
}
