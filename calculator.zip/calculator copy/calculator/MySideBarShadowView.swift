//
//  MySideBarShadowView.swift
//  calculator
//
//  Created by Essam Mahmoud fathy on 9/12/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class MySideBarShadowView: UIView {
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.layer.shadowColor = UIColor.black.withAlphaComponent(0.4).cgColor
        self.layer.shadowRadius = 3
        self.layer.shadowOffset = CGSize(width: 4, height: -3)
        self.layer.shadowOpacity = 0.35
        
        
    }
}
